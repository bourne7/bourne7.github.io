$(document).ready(function () {
  var sidebarTop = $('.header-inner').height() + 10;

  $('#sidebar').css({ 'margin-top': sidebarTop }).show();

  console.log("\n\nGiant\n\nTo be a giant.\nThis has forever been our passion, this desire to be a giant.\nNot to stand on one’s shoulders or have one for a friend.\nFor these may be fortunate things.\nBut to be one.\nGiants step over barriers that seem never ending.\nThey conquer mountains that appear insurmountable.\nGiant rise above fear.\nTriumph over pain.\nPush themselves and inspire others.\nTo be a Giant.\nTo do Giant things.\nTo take Giant steps.\nTo move the world forward.\n\n\n巨人\n\n成为一个巨人，\n这永远是我们最强烈的欲望，成为一个巨人。\n不是站在一个巨人的肩上，或是成为他的朋友。\n那或许是靠运气。\n而要成为一个巨人是不一样的，\n巨人们跨越看似无尽的障碍。\n他们征服貌似不可超越的高山。\n巨人们超越恐惧。\n击败痛苦。\n鞭策自己，鼓励他人。\n成为一个巨人，\n做巨人做的事。\n走巨人走的路。\n推动整个世界向前进。\n");

});
